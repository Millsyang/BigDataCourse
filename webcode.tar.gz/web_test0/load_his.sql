load data local inpath '/opt/data_tmp/reco.txt' overwrite into table db_hive_student.newreco;
