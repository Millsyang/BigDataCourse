load data local inpath '/opt/data_tmp/fut.txt' overwrite into table db_hive_student.fut;
